import {Carousel} from "./Carousel";
/**
 * Created by Dell on 5/4/2017.
 */

export class CarouselResponse{
    code: number;
    msg: string;
    data: Carousel[];
}
