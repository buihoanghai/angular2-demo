/**
 * Created by Dell on 5/4/2017.
 */

export class Recommendation{
    contentId: string;
    title: string;
    description: string;
    logoURL: string;
    webPlayURL: string;
    imdbPosterUrl: string;
    vodUploadName: string;
    writer: string;
    director: string;
    actor: string;
}

