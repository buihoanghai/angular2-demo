import {Recommendation} from "./Recommendation";
/**
 * Created by Dell on 5/4/2017.
 */

export class Carousel{
    ruleType: string;
    ruleName: string;
    position: number;
    recommendations: Recommendation[];
}