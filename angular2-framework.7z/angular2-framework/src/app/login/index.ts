/**
 * Created by Dell on 4/25/2017.
 */

export * from './login.component';