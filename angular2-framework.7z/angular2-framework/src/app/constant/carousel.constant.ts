/**
 * Created by Dell on 5/4/2017.
 */

export class CarouselConstant {
    static readonly CAROUSEL_HOST: string = 'http://10.88.96.85';
    static readonly CAROUSEL_PORT: string = '8096';
    static readonly CAROUSEL_URI: string = '/carousel/api/carousel?groupName=Group-Test';

    private constructor() {
    }
}
